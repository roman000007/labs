import time
from urllib.request import urlopen
class WebPage:
    def __init__(self, url):
        self.url = url
        self._content = None
        self._t = time.time()

    @property
    def content(self):
        if not self._content or time.time() - self._t > 5:
            print("Retrieving New Page...")
            self._t = time.time()
            self._content = urlopen(self.url).read()
        return self._content
        
        
        

webpage = WebPage("https://www.gutenberg.org/wiki/Animals-Domestic_(Bookshelf)")
now = time.time()
content1 = webpage.content
print(time.time() - now)
now = time.time()
input()
content2 = webpage.content
print(time.time() - now)
print(content2 == content1)